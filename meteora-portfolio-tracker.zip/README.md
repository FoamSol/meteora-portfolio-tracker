# Meteora Portfolio Tracker

This project tracks DLMM positions on Meteora using a React frontend and Node backend.

## How to run

1. `cd backend && npm install && npm start`
2. `cd frontend && npm install && npm run dev`
